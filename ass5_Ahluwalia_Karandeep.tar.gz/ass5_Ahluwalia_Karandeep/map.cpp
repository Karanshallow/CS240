#include "map.h"
#include <string>
#include <iostream>
#include <assert.h>
using namespace std;


Map::Map(){
  cout<<"Default constructor is called"<<endl;
  head = nullptr;
	length =0;
}
bool Map::empty() const{
  return (length ==0);
}
//input: none
//output: returns true if the Map is empty; else false
//side effects: none
void Map:: operator=(const Map& mapped){
  cout<<"Equal operator called"<<endl;
  node* a = head;
  while(a!=nullptr){
    node *b = a->next;
    delete a;
    a = b;
    length--;
  }
  head = nullptr;
  length = 0;
  node* c  = mapped.head;
  while(c!= nullptr){
    add(c->data);
    c = c->next;
  }
}

int Map::size() const{
  return length;
}
//input: none
//output: returns the number of elements in the Map
//side effects: none

bool Map::add(ElementType element){
if(!find(element.first)){
  node* newNode = new node;
	newNode->data = element;
  if (length==0){
    newNode->next = head;
    head = newNode;
  }else{
  node* p = head;
//  cout<<"This is point j"<<endl;
  while((p->next!= nullptr)&&(p->next->data.first<p->data.first)){
    p = p->next;
  }
//  cout<<"This is point k"<<endl;
  newNode->next = p->next;
//  cout<<"This is point l"<<endl;
  p->next = newNode;
}
//  cout<<"This is point m"<<endl;
	length++;
	return true;
}else{
  return false;
}
}
//input: an element (key and its associated value)
//output: returns true if the key-value pair was 				     	//        added; else false(the key was found)
//side effects: Map has one more element (if addition      		     	//              done)

bool Map::find(KeyType key) const{
if (length!=0){
  node* p = head;
  while(p!=nullptr){
    if (p->data.first == key){
      return true;
    }else{
      p = p->next;
    }
  }
}
return false;
}
ValueType Map::retrieve(KeyType key) const{
  assert(find(key));
  if (length!=0){
    node* p = head;
    while(p!=nullptr){
      if (p->data.first == key){
        return p->data.second;
      }else{
        p = p->next;
      }
    }
  }
  return NULL;
}
//input: a key
//output: returns the value associated with key (a 			//        null pointer if the key was not found)
//side effects: none

bool Map::remove(KeyType key){
  if (find(key)){
    node* p = head;
    node* a = nullptr;
    while(p!=nullptr){
      if (p->data.first == key){
        a->next= p->next;
        delete p;
        length--;
        return true;
      }else{
        a = p;
        p = p->next;
      }
    }
  }
  return false;
}
Map::Map(const Map & mapped){
  cout<<"Map copy constructor is called"<<endl;
  head = nullptr;
  length = 0;
  node* a  = mapped.head;
  while(a!= nullptr){
    add(a->data);
    a = a->next;
  }
}
Map::~Map(){
  cout<<"Map destructor is called"<<endl;
  node* a = head;
  while(a!=nullptr){
    node *b = a->next;
    delete a;
    a = b;
    length--;
  }
}
void Map::displayAll() const{
  node *p = head;
  int item = 1;
  if (length==0){
    cout<<"Map is empty"<<endl;
  }
  while(p!= nullptr){
    string* str = p->data.second;
    cout<<"List item "<<item<<"    key: "<<p->data.first;
    cout<<"       value: "<<str<<endl;
    item++;
    p = p->next;
  }
}
  //input: a key
//output: returns true if item is removed;
//        else false (key not found)
//side effects: Map has one less element (if remove 			//              done)
//void map::displayAll() const;
  // write contents of the Map to cout
